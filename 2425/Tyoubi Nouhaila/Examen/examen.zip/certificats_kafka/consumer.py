import csv
from confluent_kafka import Consumer
from collections import defaultdict

# Configuration du consommateur Kafka
consumer_config = {
    'bootstrap.servers': 'kafka-4af1ece-nouhailatyoubi-9283.d.aivencloud.com:12692',
    'security.protocol': 'SSL',
    'ssl.ca.location': 'ca.pem',
    'ssl.certificate.location': 'service.cert',
    'ssl.key.location': 'service.key',
    'group.id': 'CONSUMER_GROUP_ID',
    'auto.offset.reset': 'earliest'
}
# Création d'un consommateur Kafka avec la configuration
consumer = Consumer(consumer_config)


# Souscription au topic 'etudiants_topic'
consumer.subscribe(['etudiants_topic'])

# Liste pour stocker les données transformées
transformed_data = []

try:
    # Boucle pour lire les messages en continu
    while True:
        msg = consumer.poll(1.0)  # Lecture des messages avec un timeout de 1 seconde
        if msg is None:
            continue  # Si aucun message n'est reçu, passer à l'itération suivante
        if msg.error(): # Gestion des erreurs liées à la réception des messages
            print(f"Consumer error: {msg.error()}")
            continue

        # Décodage du message Kafka
        message = msg.value().decode('utf-8')
        print(f"Received message: {message}")

        try:
            # Extraction des informations du message (Prénom, Nom, Âge, Filière)
            name, age, field = message.split(', ')
            first_name, last_name = name.split(' ')

            age = int(age)  # Conversion de l'âge en entier

            # Transformation : noms en majuscules
            first_name = first_name.upper()
            last_name = last_name.upper()

            # Filtrage : étudiants de plus de 20 ans
            if age > 20:
                transformed_data.append({
                    'first_name': first_name,
                    'last_name': last_name,
                    'age': age,
                    'field': field
                })
        except ValueError:
            print("Erreur de formatage des données reçues. Ignoré.")
except KeyboardInterrupt:# Arrêt de la boucle en cas d'interruption par l'utilisateur
    print("Arrêt du consommateur.")
finally:
   # Fermeture du consommateur Kafka pour libérer les ressources 
    consumer.close()

# Calcul des statistiques : Moyenne d'âge par filière
stats = defaultdict(list) # Utilisation d'un dictionnaire de listes pour grouper les âges par filière
for student in transformed_data:
    stats[student['field']].append(student['age']) # Ajouter l'âge de l'étudiant à la filière correspondante

# Calcul de la moyenne d'âge pour chaque filière
average_age_by_field = {
    field: sum(ages) / len(ages) for field, ages in stats.items()  # Moyenne = somme des âges / nombre d'étudiants
}

# Affichage des statistiques calculées
print("\nStatistiques : Moyenne d'âge par filière")
for field, avg_age in average_age_by_field.items():
    print(f"Filière: {field}, Âge moyen: {avg_age:.2f}")

# Sauvegarde des données transformées dans un fichier CSV
output_file = "etudiants_transformed.csv"

with open(output_file, mode='w', newline='', encoding='utf-8') as file:
    writer = csv.DictWriter(file, fieldnames=['first_name', 'last_name', 'age', 'field'])
    writer.writeheader()  # Écrire l'en-tête dans le fichier CSV
    writer.writerows(transformed_data)  # Écrire les lignes de données transformées

print(f"\nDonnées transformées sauvegardées dans {output_file}")
