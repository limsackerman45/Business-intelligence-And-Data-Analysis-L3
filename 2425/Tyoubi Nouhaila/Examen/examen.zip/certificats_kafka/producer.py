from confluent_kafka import Producer
import random
from faker import Faker

# Initialisation de Faker pour générer des noms et prénoms aléatoires
fake = Faker()

# Liste des différentes filières que l'on peut associer à un étudiant
fields = ["Science", "Engineering", "Business", "Arts", "Medical", "Law", "Education"]

# Fonction de retour d'information sur la livraison du message
def delivery_report(err, msg):
    if err is not None:
        print(f"Message delivery failed: {err}")
    else:
        print(f"Message delivered to {msg.topic()} [{msg.partition()}]")
# Configuration du producteur Kafka
producer = Producer({
    'bootstrap.servers': 'kafka-4af1ece-nouhailatyoubi-9283.d.aivencloud.com:12692',
    'security.protocol': 'SSL',
    'ssl.ca.location': 'ca.pem',
    'ssl.certificate.location': 'service.cert',
    'ssl.key.location': 'service.key',
})

# Génération de données aléatoires pour 100 étudiants
for i in range(100):
    
    # Générer un prénom et un nom aléatoires à l'aide de Faker
    first_name = fake.first_name()  
    last_name = fake.last_name()  
    
     # Générer un âge aléatoire entre 18 et 30
    age = fake.random_int(min=18, max=30)  
    
    # Sélectionner aléatoirement une filière parmi la liste
    field = random.choice(fields) 
    
    # Créer une chaîne de caractères représentant un étudiant (nom, prénom, âge, filière) 
    student_data = f"{first_name} {last_name}, {age}, {field}"
    
    # Envoyer les données générées au topic Kafka 'etudiants_topic'
    producer.produce('etudiants_topic', student_data, callback=delivery_report)
    # Assurer la livraison du message
    producer.flush()
