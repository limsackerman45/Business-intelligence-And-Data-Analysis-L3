export interface SeismicEvent {
  id: string;
  timestamp: number;
  magnitude: number;
  latitude: number;
  longitude: number;
  depth: number;
}

export interface SeismicStatistics {
  averageMagnitude: number;
  maxMagnitude: number;
  totalEvents: number;
}

export interface AlarmState {
  isActive: boolean;
  message: string;
}

