import React from 'react';
import { ComposableMap, Geographies, Geography, Marker } from 'react-simple-maps';
import { SeismicEvent } from '../../../types/seismic';

interface SeismicMapProps {
  events: SeismicEvent[];
  region: string;
}

const geoUrl = {
  japan: "/japan.json",
  morocco: "/morocco.json",
  drc: "/drc.json"
};

const SeismicMap: React.FC<SeismicMapProps> = ({ events, region }) => {
  const mapCenter = {
    japan: [138, 38],
    morocco: [-6, 32],
    drc: [23, -3]
  };

  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg border border-blue-500">
      <h2 className="text-2xl font-bold mb-6 text-blue-400">Seismic Activity Map - {region}</h2>
      <div className="aspect-video bg-gray-800 rounded-lg border border-blue-400">
        <ComposableMap projection="geoMercator" projectionConfig={{ center: mapCenter[region], scale: 1000 }}>
          <Geographies geography={geoUrl[region]}>
            {({ geographies }) =>
              geographies.map((geo) => (
                <Geography
                  key={geo.rsmKey}
                  geography={geo}
                  fill="#2C3E50"
                  stroke="#EAEAEC"
                  strokeWidth={0.5}
                />
              ))
            }
          </Geographies>
          {events.map((event) => (
            <Marker key={event.id} coordinates={[event.longitude, event.latitude]}>
              <circle r={Math.max(event.magnitude, 1)} fill="#E74C3C" fillOpacity={0.6} />
            </Marker>
          ))}
        </ComposableMap>
      </div>
      <ul className="mt-4">
        {events.slice(-5).map((event) => (
          <li key={event.id} className="text-sm text-blue-200 mb-2 flex justify-between">
            <span>Magnitude {event.magnitude.toFixed(1)}</span>
            <span>({event.latitude.toFixed(2)}, {event.longitude.toFixed(2)})</span>
          </li>
        ))}
      </ul>
    </div>
  );
};

export default SeismicMap;

