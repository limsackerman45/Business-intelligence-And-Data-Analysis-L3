import React from 'react';
import { SeismicStatistics, AlarmState } from '../../../types/seismic';

interface StatisticsPanelProps {
  statistics: SeismicStatistics;
  alarmState: AlarmState;
}

const StatisticsPanel: React.FC<StatisticsPanelProps> = ({ statistics, alarmState }) => {
  return (
    <div className="bg-gray-900 p-6 rounded-lg shadow-lg border border-blue-500">
      <h2 className="text-2xl font-bold mb-6 text-blue-400">Seismic Statistics</h2>
      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <div className="bg-gray-800 p-4 rounded-lg border border-blue-400">
          <h3 className="text-lg font-semibold text-blue-300">Average Magnitude</h3>
          <p className="text-4xl font-bold text-blue-200">{statistics.averageMagnitude.toFixed(2)}</p>
        </div>
        <div className={`p-4 rounded-lg border ${alarmState.isActive ? 'bg-red-900 border-red-500 animate-pulse' : 'bg-gray-800 border-blue-400'}`}>
          <h3 className="text-lg font-semibold text-blue-300">Max Magnitude</h3>
          <p className="text-4xl font-bold text-blue-200">{statistics.maxMagnitude.toFixed(2)}</p>
        </div>
        <div className="bg-gray-800 p-4 rounded-lg border border-blue-400">
          <h3 className="text-lg font-semibold text-blue-300">Total Events</h3>
          <p className="text-4xl font-bold text-blue-200">{statistics.totalEvents}</p>
        </div>
      </div>
      {alarmState.isActive && (
        <div className="mt-6 bg-red-800 p-4 rounded-lg border border-red-500 animate-pulse">
          <h3 className="text-xl font-bold text-red-200">ALARM</h3>
          <p className="text-lg text-red-100">{alarmState.message}</p>
        </div>
      )}
    </div>
  );
};

export default StatisticsPanel;

