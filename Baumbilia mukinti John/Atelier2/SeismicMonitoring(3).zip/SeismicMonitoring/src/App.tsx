import React, { useState, useEffect } from 'react';
import SeismicMap from './features/seismic/components/SeismicMap';
import StatisticsPanel from './features/seismic/components/StatisticsPanel';
import { SeismicEvent, SeismicStatistics, AlarmState } from './types/seismic';

const generateSeismicEvent = (region: string): SeismicEvent => {
  const coordinates = {
    japan: { lat: [30, 46], lon: [129, 146] },
    morocco: { lat: [27, 36], lon: [-13, -1] },
    drc: { lat: [-13, 5], lon: [12, 31] }
  };

  const { lat, lon } = coordinates[region];

  return {
    id: Math.random().toString(36).substr(2, 9),
    timestamp: Date.now(),
    magnitude: Math.random() * 8,
    latitude: Math.random() * (lat[1] - lat[0]) + lat[0],
    longitude: Math.random() * (lon[1] - lon[0]) + lon[0],
    depth: Math.random() * 700,
  };
};

const calculateStatistics = (events: SeismicEvent[]): SeismicStatistics => {
  const magnitudes = events.map(e => e.magnitude);
  return {
    averageMagnitude: magnitudes.reduce((a, b) => a + b, 0) / events.length,
    maxMagnitude: Math.max(...magnitudes),
    totalEvents: events.length,
  };
};

const ALARM_THRESHOLD = 7.98;

const App: React.FC = () => {
  const [region, setRegion] = useState<string>('japan');
  const [events, setEvents] = useState<SeismicEvent[]>([]);
  const [statistics, setStatistics] = useState<SeismicStatistics>({
    averageMagnitude: 0,
    maxMagnitude: 0,
    totalEvents: 0,
  });
  const [alarmState, setAlarmState] = useState<AlarmState>({
    isActive: false,
    message: '',
  });

  useEffect(() => {
    const interval = setInterval(() => {
      const newEvent = generateSeismicEvent(region);
      setEvents(prevEvents => [...prevEvents, newEvent].slice(-100));
    }, 2000);

    return () => clearInterval(interval);
  }, [region]);

  useEffect(() => {
    const newStatistics = calculateStatistics(events);
    setStatistics(newStatistics);

    let audio: HTMLAudioElement | null = null;

    if (newStatistics.maxMagnitude > ALARM_THRESHOLD && !alarmState.isActive) {
      setAlarmState({
        isActive: true,
        message: `警告：最大震度が${ALARM_THRESHOLD}を超えました。安全な場所に避難してください。`,
      });
      // Try to play alarm sound
      audio = new Audio('/alarm.mp3');
      audio.loop = true;
      audio.play().catch(error => {
        console.error('Failed to play alarm sound:', error);
        // Fallback to visual alarm only
      });
    } else if (newStatistics.maxMagnitude <= ALARM_THRESHOLD && alarmState.isActive) {
      setAlarmState({
        isActive: false,
        message: '',
      });
      // Stop alarm sound if it's playing
      if (audio) {
        audio.pause();
        audio.currentTime = 0;
      }
    }

    // Cleanup function
    return () => {
      if (audio) {
        audio.pause();
        audio.currentTime = 0;
      }
    };
  }, [events, alarmState.isActive]);

  return (
    <div className="min-h-screen bg-gray-950 text-white">
      <div className="container mx-auto p-8">
        <h1 className="text-4xl font-bold mb-8 text-blue-400">Seismic Monitoring Dashboard</h1>
        <div className="mb-4">
          <label htmlFor="region-select" className="mr-2">Select Region:</label>
          <select
            id="region-select"
            value={region}
            onChange={(e) => setRegion(e.target.value)}
            className="bg-gray-800 text-white p-2 rounded"
          >
            <option value="japan">Japan</option>
            <option value="morocco">Morocco</option>
            <option value="drc">Democratic Republic of Congo</option>
          </select>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
          <SeismicMap events={events} region={region} />
          <StatisticsPanel statistics={statistics} alarmState={alarmState} />
        </div>
      </div>
    </div>
  );
};

export default App;

